clear all
close all
clc

a = 1;
b = 2;
c = 1;

y = parabola(a,b,c);